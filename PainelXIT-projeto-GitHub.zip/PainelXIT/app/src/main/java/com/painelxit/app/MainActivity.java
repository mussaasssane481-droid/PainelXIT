package com.painelxit.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    int red = Color.rgb(255,59,48), bg = Color.rgb(16,16,20), card = Color.rgb(31,31,38), white = Color.WHITE, muted = Color.rgb(190,190,200);
    LinearLayout root;
    @Override public void onCreate(Bundle b) { super.onCreate(b); build(); }
    TextView text(String s, int size, int color) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,8,0,8); return t; }
    Button button(String s) { Button b=new Button(this); b.setText(s); b.setTextColor(white); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red)); return b; }
    void build() {
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(22,24,22,28); root.setBackgroundColor(bg); scroll.addView(root); setContentView(scroll);
        TextView logo=text("⚡ PAINEL XIT",26,white); logo.setTypeface(null,Typeface.BOLD); root.addView(logo);
        root.addView(text("FREE FIRE • FERRAMENTAS DE TREINO",12,red));
        panel("SENSIBILIDADE — PONTO DE PARTIDA", "Geral:  ⭐ 180–195\nPonto vermelho: 170–190\nMira 2x: 155–175\nMira 4x: 135–160\nMira AWM: 30–60\nOlhadinha: 120–180\n\nValores sugeridos para testar, não são universais. Ajusta conforme a resposta do teu ecrã e as opções disponíveis no jogo.");
        panel("TREINO DE CAPA", "1. Entra no campo de treino.\n2. Faz 10 arrastos curtos para cima.\n3. Alterna entre alvo parado e movimento.\n4. Regista quantos tiros acertam na cabeça.\n5. Muda a sensibilidade pouco a pouco.");
        panel("HUD — DICAS", "• Coloca o botão de disparo onde o polegar alcança sem esforço.\n• Evita cobrir a visão dos alvos.\n• Treina primeiro com uma configuração e muda só uma coisa de cada vez.");
        Button overlay=button("ATIVAR JANELA FLUTUANTE"); overlay.setOnClickListener(v -> { if (Settings.canDrawOverlays(this)) startService(new Intent(this,OverlayService.class)); else { Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i); Toast.makeText(this,"Autoriza 'mostrar sobre outras aplicações' e volta ao Painel XIT.",Toast.LENGTH_LONG).show(); } }); root.addView(overlay);
        Button stop=button("FECHAR JANELA FLUTUANTE"); stop.setOnClickListener(v -> stopService(new Intent(this,OverlayService.class))); root.addView(stop);
        root.addView(text("Ferramenta independente de treino. Não altera o Free Fire, não faz mira automática e não promete aumentar automaticamente a precisão.",12,muted));
    }
    void panel(String title,String body) { LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(16,12,16,14); box.setBackgroundTintList(null); box.setBackgroundColor(card); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,18,0,0); root.addView(box,p); TextView h=text(title,16,red); h.setTypeface(null,Typeface.BOLD); box.addView(h); TextView t=text(body,14,white); box.addView(t); }
}
