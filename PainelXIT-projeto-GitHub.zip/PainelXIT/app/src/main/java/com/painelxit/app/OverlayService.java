package com.painelxit.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    WindowManager wm; View panel;
    @Override public void onCreate() { super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(18,12,18,12); box.setBackgroundColor(Color.argb(235,25,25,32));
        TextView title=new TextView(this); title.setText("⚡ XIT  •  TREINO"); title.setTextColor(Color.rgb(255,70,60)); title.setTextSize(16); title.setPadding(0,0,0,8); box.addView(title);
        TextView info=new TextView(this); info.setText("Arrastos curtos\nMira estável\nTreina no campo de treino"); info.setTextColor(Color.WHITE); info.setTextSize(13); box.addView(info);
        TextView close=new TextView(this); close.setText("FECHAR  ×"); close.setTextColor(Color.WHITE); close.setPadding(0,10,0,0); close.setOnClickListener(v->stopSelf()); box.addView(close); panel=box;
        int type=android.os.Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT); lp.gravity=Gravity.TOP|Gravity.END; lp.x=20; lp.y=180;
        try { wm.addView(panel,lp); } catch(Exception e) { stopSelf(); }
    }
    @Override public void onDestroy(){ if(wm!=null&&panel!=null) try{wm.removeView(panel);}catch(Exception ignored){} super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}
