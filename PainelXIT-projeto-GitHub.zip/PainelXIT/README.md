# Painel XIT — projeto Android inicial

Aplicação Android independente com recomendações de sensibilidade, guia de treino de capa, dicas de HUD e uma pequena janela flutuante opcional que usa a permissão oficial de sobreposição do Android.

## Compilar
- Android Studio recente + JDK 17, ou Gradle 8.9+ com Android Gradle Plugin 8.7.3.
- Abrir a pasta no Android Studio e executar Build > Build APK(s), ou executar `gradle assembleDebug`.
- O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Também existe um workflow GitHub Actions em `.github/workflows/android.yml` para gerar o APK ao enviar o projeto para um repositório GitHub e executar manualmente o workflow. O APK debug é para testes; uma distribuição pública requer testes em dispositivo e assinatura adequada.

A janela flutuante requer que o utilizador permita manualmente “Mostrar sobre outras aplicações”. O projeto não interage com a memória nem altera os ficheiros do Free Fire. As sensibilidades são apenas sugestões de partida e devem ser ajustadas no próprio jogo.
